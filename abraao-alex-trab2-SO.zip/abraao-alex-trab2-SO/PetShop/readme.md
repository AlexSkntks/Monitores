#Como executar

Digite make no com o terminal aberto no diretório dos arquivos fonte

`make`

Em seguida digite:

`./petShop`

para executar o programa.