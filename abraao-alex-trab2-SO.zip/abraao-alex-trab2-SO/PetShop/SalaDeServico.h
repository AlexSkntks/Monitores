#ifndef _SALA_
	#define _SALA_

	void um_gato_quer_servico();
	void gato_atendido();
	void um_cao_quer_servivo();
	void cao_atendido();
	int inicializaSala(int maximo);
	void desalocaEstruturas();
#endif