#Como executar

Digite make no com o terminal aberto no diretório dos arquivos fonte

`make`

Em seguida digite:

`./torcedores`

para executar o programa.