#ifndef _MONITOR_
	#define _MONITOR_

	void flamenguistaSai();
	void flamenguistaQuerEntrar();
	void vascainoQuerEntrar();
	void vascainoQuerSair();

#endif